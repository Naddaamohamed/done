#!/bin/bash

# Define input and output files
input_file="allreport.txt"
output_file="simple_chat_ai/cve_numbers.txt"

# Extract CVE numbers and save to output file
echo "'this is a report form scaning tool vulnerabilities of a web site , not explain any thing and dont write any thing but,if you find a word called "CVE" in this report,write this word in a table with the number which come after this word untill the last number and  just search about patches for these CVEs from (cve.Mitre.org link) and give me links for patches and write these patches in anthor column and if not find "CVE" just write "this report dont exist CVEs"
 ,dont give me any explain and recommandations , i need just links about patches of CVEs or dont return any thing please'(" > "$output_file"
grep -oP 'CVE-\d{4}-\d{4,}' "$input_file" | sort -u >> "$output_file"
echo ")"
echo "CVE numbers have been extracted to $output_file"
